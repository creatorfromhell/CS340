#See PyCharm help at https://www.jetbrains.com/help/pycharm/
#Press Shift+F10 to execute it or replace it with your code.
from pymongo import MongoClient
from bson.objectid import ObjectId
from urllib.parse import quote_plus

class AnimalShelter:
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, host, port, db, col, username, password):
        #
        # Initialize Connection
        #
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32082
        DB = 'AAC'
        COL = 'animals'
        
        #sanitize username and passworld and strip whitespace.
        username = quote_plus(username.strip())
        password = quote_plus(password.strip())
        
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (username,password,host,port))
        self.database = self.client['%s' % (db)]
        self.collection = self.database['%s' % (col)]

    # Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            insert_dictionary = self.database.animals.insert_one(data)
            if insert_dictionary != 0:
                return True
            else:
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    # Create method to implement the R in CRUD.
    def read(self, id=None):#default for id is None
        if id is not None:#Check if id is not None
            animal_find = self.database.animals.find(id, {"_id": False})#Omit ID of each document, return what matches the criteria
        else:#return all if id is None
            animal_find = self.database.animals.find({}, {"_id": False})
        return animal_find


    #Implement update function, to save and update db based on
    def update(self, search, update):
        if search is not None: #check if search is None
            result = self.database.animals.update_many(search, {'$set': update})
            return result.raw_result
        else:#raise exception if save is none
            raise Exception("Failed to save, save parameter is empty")

    #Delete function
    def delete(self, remove):
        if remove is not None: #check if remove is None
            result = self.database.animals.delete_many(remove)
            return result.raw_result
        else:#raise exception if remove is none
            raise Exception("Remove parameter is empty, failed to delete.")